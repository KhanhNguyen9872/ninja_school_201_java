// 
// Decompiled by Procyon v0.5.36
// 

public final class SkillTemplate
{
    public byte id;
    public String Class2;
    public int Class3;
    public int type;
    public int iconId;
    public String[] Class6;
    public Skill[] Class7;
}
