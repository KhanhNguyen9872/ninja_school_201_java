// 
// Decompiled by Procyon v0.5.36
// 

public final class Game110
{
    private int Class1;
    private int Class2;
    private int Class3;
    private int Class4;
    private int Class5;
}
