import javax.microedition.lcdui.Image;

// 
// Decompiled by Procyon v0.5.36
// 

public final class Game11
{
    public Image Class1;
    public long Class2;
    public long Class3;
    public byte Class4;
    
    public Game11() {
        this.Class1 = null;
        this.Class2 = 0L;
        this.Class3 = System.currentTimeMillis();
        this.Class4 = 0;
    }
}
