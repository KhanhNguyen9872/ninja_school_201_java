// 
// Decompiled by Procyon v0.5.36
// 

public final class Game41
{
    public int Class1;
    public int Class2;
    public int Class3;
    public String Class4;
    public boolean Class5;
    public int Class6;
    public int Class7;
    
    public Game41(final int n, final int class2, final int class3, final String class4, final int class5, final boolean class6) {
        switch (n) {
            case 0: {
                this.Class1 = 647;
                break;
            }
            case 1: {
                this.Class1 = 1182;
                break;
            }
            case 2: {
                this.Class1 = 1181;
                break;
            }
            case 3: {
                this.Class1 = 643;
                break;
            }
            case 4: {
                this.Class1 = 645;
                break;
            }
            case 5: {
                this.Class1 = 676;
                break;
            }
            case 6: {
                this.Class1 = 1119;
                break;
            }
        }
        this.Class2 = class2;
        this.Class3 = class3;
        this.Class4 = class4;
        this.Class6 = class5;
        this.Class5 = class6;
    }
}
