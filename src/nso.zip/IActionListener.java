// 
// Decompiled by Procyon v0.5.36
// 

public interface IActionListener
{
    void perform(final int p0, final Object p1);
}
