// 
// Decompiled by Procyon v0.5.36
// 

public final class EffectTemplate
{
    public byte id;
    public byte type;
    public int iconId;
}
