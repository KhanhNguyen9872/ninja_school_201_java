// 
// Decompiled by Procyon v0.5.36
// 

public final class Game30
{
    private static Game71 Class1;
    
    static {
        Game30.Class1 = new Game71();
    }
    
    public static void Class1(final Skill skill) {
        Game30.Class1.Class1(skill.Class2, skill);
    }
    
    public static Skill Class1(final short s) {
        return (Skill)Game30.Class1.Class1(s);
    }
}
