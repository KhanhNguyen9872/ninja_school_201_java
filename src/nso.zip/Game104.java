// 
// Decompiled by Procyon v0.5.36
// 

public final class Game104
{
    public static Game71 Class1;
    
    static {
        Game104.Class1 = new Game71();
    }
    
    public static void Class1(final ItemTemplate itemTemplate) {
        Game104.Class1.Class1(itemTemplate.id, itemTemplate);
    }
    
    public static ItemTemplate Class1(final short s) {
        return (ItemTemplate)Game104.Class1.Class1(s);
    }
    
    public static short Class2(final short n) {
        return Class1(n).Class7;
    }
}
