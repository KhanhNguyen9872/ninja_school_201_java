// 
// Decompiled by Procyon v0.5.36
// 

public final class Game80
{
    public String Class1;
    public byte Class2;
    
    public Game80(final String class1, final byte class2) {
        this.Class1 = class1;
        this.Class2 = class2;
    }
}
