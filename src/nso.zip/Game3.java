// 
// Decompiled by Procyon v0.5.36
// 

public final class Game3
{
    private int Class1;
    private int Class2;
    private int Class3;
    private int Class4;
    private boolean Class5;
    private short Class6;
    private short Class7;
    private short Class8;
    private short Class9;
    private MyVector Class10;
    private MyVector Class11;
    
    private Game3(final byte b) {
    }
    
    private Game3(final char c) {
    }
    
    private Game3() {
        new MyVector();
        new MyVector();
    }
}
