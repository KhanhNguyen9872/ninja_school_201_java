// 
// Decompiled by Procyon v0.5.36
// 

public class PKBoss extends Auto
{
}
