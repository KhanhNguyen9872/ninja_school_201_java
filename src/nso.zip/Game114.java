// 
// Decompiled by Procyon v0.5.36
// 

public final class Game114
{
    public String Class1;
    public byte Class2;
    public short Class3;
    public short Class4;
    public int Class5;
    public String Class6;
    public MyVector Class7;
    public int Class8;
    public int Class9;
    public long Class10;
    
    public Game114(final String class1, final byte class2, final short class3, final short class4, final int class5, final String class6, final MyVector class7, final int class8, final int class9) {
        this.Class1 = "";
        this.Class5 = -1;
        this.Class6 = "";
        this.Class7 = new MyVector();
        this.Class8 = -1;
        this.Class9 = -1;
        this.Class1 = class1;
        this.Class3 = class3;
        this.Class4 = class4;
        this.Class5 = class5;
        this.Class6 = class6;
        this.Class7 = class7;
        this.Class8 = class8;
        this.Class9 = class9;
        this.Class10 = System.currentTimeMillis();
        this.Class2 = class2;
    }
}
