import javax.microedition.lcdui.Image;

// 
// Decompiled by Procyon v0.5.36
// 

public final class Game82
{
    public Image Class1;
    public long Class2;
}
