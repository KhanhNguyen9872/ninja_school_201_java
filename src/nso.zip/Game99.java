// 
// Decompiled by Procyon v0.5.36
// 

public final class Game99
{
    public Game49[] Class1;
    
    public Game99(final int n) {
        if (n == 0) {
            this.Class1 = new Game49[8];
        }
        if (n == 1) {
            this.Class1 = new Game49[18];
        }
        if (n == 2) {
            this.Class1 = new Game49[10];
        }
        if (n == 3) {
            this.Class1 = new Game49[2];
        }
    }
}
