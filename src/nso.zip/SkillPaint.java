// 
// Decompiled by Procyon v0.5.36
// 

public final class SkillPaint
{
    public int id;
    public Game18[] Class2;
    public Game18[] Class3;
}
