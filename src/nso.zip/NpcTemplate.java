// 
// Decompiled by Procyon v0.5.36
// 

public final class NpcTemplate
{
    public int npcTemplateId;
    public String name;
    public int headId;
    public int bodyId;
    public int legId;
    public String[][] menu;
}
