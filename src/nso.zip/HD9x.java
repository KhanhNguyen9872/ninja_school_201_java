// 
// Decompiled by Procyon v0.5.36
// 

public final class HD9x extends Auto
{
    public final void Run() {
    }
}
