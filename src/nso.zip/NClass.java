// 
// Decompiled by Procyon v0.5.36
// 

public final class NClass
{
    public int classId;
    public String Class2;
    public SkillTemplate[] Class3;
}
