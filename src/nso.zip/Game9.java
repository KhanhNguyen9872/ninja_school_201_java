// 
// Decompiled by Procyon v0.5.36
// 

public final class Game9
{
    private MyVector Class1;
    private MyVector Class2;
    private int Class3;
    private int Class4;
    private int Class5;
    private int Class6;
    private int Class7;
    
    private Game9() {
        new MyVector();
        new MyVector();
    }
}
