// 
// Decompiled by Procyon v0.5.36
// 

public final class Game70
{
    public byte[] Class1;
    
    public Game70() {
        new MyVector();
        new MyVector();
    }
}
