import javax.microedition.lcdui.Image;

// 
// Decompiled by Procyon v0.5.36
// 

public final class MobTemplate
{
    public byte Class1;
    public byte Class2;
    public byte Class3;
    public byte Class4;
    public short Class5;
    public int hp;
    public String name;
    public Image[] Class8;
    public Game76[] Class9;
    public Game74[] Class10;
    public byte[] Class11;
    public byte[][] Class12;
    public byte[][] Class13;
    public byte[] Class14;
    public byte[] Class15;
    
    public MobTemplate() {
        this.Class4 = 0;
        this.Class13 = new byte[4][];
        this.Class15 = new byte[4];
    }
}
