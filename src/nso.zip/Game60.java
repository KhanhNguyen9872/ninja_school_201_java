// 
// Decompiled by Procyon v0.5.36
// 

public final class Game60
{
    public int Class1;
    public String Class2;
    public String Class3;
}
