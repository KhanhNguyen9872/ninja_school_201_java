// 
// Decompiled by Procyon v0.5.36
// 

public final class Game66
{
    public short Class1;
    public short Class2;
    public short Class3;
    public byte Class4;
    public byte Class5;
    
    public Game66(final int n, final int n2, final int n3) {
        this.Class5 = 0;
        this.Class1 = (short)n3;
        this.Class2 = (short)n;
        this.Class3 = (short)n2;
    }
}
