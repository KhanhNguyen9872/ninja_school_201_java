// 
// Decompiled by Procyon v0.5.36
// 

public final class Game58
{
    public int Class1;
    public int Class2;
    public int Class3;
    
    public Game58(final int class1, final int class2, final int class3) {
        this.Class1 = class1;
        this.Class2 = class2;
        this.Class3 = class3;
    }
    
    public Game58(final int class1, final int class2) {
        this.Class1 = class1;
        this.Class2 = class2;
    }
}
