// 
// Decompiled by Procyon v0.5.36
// 

public final class Game57
{
    public Game76[] Class1;
    public Game74[] Class2;
    public short[] Class3;
    public long Class4;
    public long Class5;
    
    public Game57() {
        this.Class4 = 0L;
        this.Class5 = System.currentTimeMillis();
    }
}
