// 
// Decompiled by Procyon v0.5.36
// 

public final class Game65
{
    public int Class1;
    public int Class2;
    public int Class3;
    public int Class4;
    public int Class5;
    public int Class6;
    
    public Game65() {
        this.Class5 = 0;
        this.Class1 = 0;
        this.Class2 = 0;
    }
    
    public Game65(final int class1, final int class2) {
        this.Class5 = 0;
        this.Class1 = class1;
        this.Class2 = class2;
    }
}
