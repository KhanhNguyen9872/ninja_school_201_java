// 
// Decompiled by Procyon v0.5.36
// 

public class SanBoss extends Auto
{
    private boolean Game28;
    private boolean Game29;
    private int Game30;
    private boolean Game31;
    public int Game1;
    private int Game32;
    private int Game33;
    private boolean Game34;
    private int Game35;
    private long Game36;
    public int Game23;
    private long Game37;
    public static boolean Pk;
    public static boolean Game25;
    public static boolean Thoigianchohoisinh;
    public static boolean MyLenga;
    
    public final void Run() {
    }
    
    public final boolean Game13() {
        return true;
    }
}
