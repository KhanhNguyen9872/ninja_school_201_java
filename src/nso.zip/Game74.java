// 
// Decompiled by Procyon v0.5.36
// 

public final class Game74
{
    public short[] Class1;
    public short[] Class2;
    public byte[] Class3;
    public byte[] Class4;
    public byte[] Class5;
}
