// 
// Decompiled by Procyon v0.5.36
// 

public final class Game87
{
    public int Class1;
    public int Class2;
    public int Class3;
    public int Class4;
    public boolean Class5;
    
    public Game87() {
    }
    
    public static void Class1(final String x) {
        System.out.println(x);
    }
    
    public Game87(final int class1, final int n) {
        this.Class3 = 3;
        this.Class1 = class1;
        this.Class4 = n;
        this.Class2 = n;
        this.Class5 = false;
    }
}
