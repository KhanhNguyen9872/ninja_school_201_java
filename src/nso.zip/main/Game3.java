// 
// Decompiled by Procyon v0.5.36
// 

package main;

import javax.microedition.lcdui.Graphics;

public abstract class Game3
{
    protected abstract void Class1(final Graphics p0);
    
    protected abstract void Class3(final int p0);
    
    protected abstract void Class4(final int p0);
    
    protected abstract void Class1(final int p0, final int p1);
    
    protected abstract void setPopupSize(final int p0, final int p1);
    
    protected abstract void Class3(final int p0, final int p1);
}
