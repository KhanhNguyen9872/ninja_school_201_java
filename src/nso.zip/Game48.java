// 
// Decompiled by Procyon v0.5.36
// 

public final class Game48
{
    public Item Class1;
    public int Class2;
    public int Class3;
    public int Class4;
    public String Class5;
    
    public Game48() {
        this.Class5 = "";
    }
}
