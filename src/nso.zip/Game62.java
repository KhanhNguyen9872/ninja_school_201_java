// 
// Decompiled by Procyon v0.5.36
// 

public final class Game62
{
    public static int Class1;
    public static int Class2;
    public static int Class3;
    public static int Class4;
    public static int Class5;
    public static int Class6;
    public static int Class7;
    public static int Class8;
    public static final int[][] Class9;
    public static final int[] Class10;
    
    static {
        Game62.Class1 = 17;
        Game62.Class2 = 20;
        Game62.Class3 = 24;
        Game62.Class4 = 33;
        Game62.Class5 = 36;
        Game62.Class6 = 40;
        Game62.Class7 = 3;
        Game62.Class8 = 6;
        Class9 = new int[][] { new int[4], { 1, 1, 1, 1 }, new int[4], { 2, 2, 2, 2 }, { 3, 3, 3, 3 }, { 4, -1, -1, 4 }, { 5, 5, 5, -1 }, { 6, 6, 6, 5 }, { 7, 7, -1, -1 }, { 8, 8, 8, 7 }, { 9, -1, -1, 8 }, { 10, -1, -1, 9 }, { 11, -1, -1, -1 }, { 13, 13, -1, -1 }, { 14, 14, 14, -1 }, { 15, 15, -1, -1 }, { 16, 16, 16, -1 } };
        Class10 = new int[] { 5614318, 4751608, 1052688, 2081781, 2081781, 0, 10541304, 2526662, 1513480, 16760764, 0, 1285290, 1285290, 0, 4882101, 3018762, 4352644 };
    }
}
