// 
// Decompiled by Procyon v0.5.36
// 

public final class EffectPaint
{
    public int Class1;
    public Mob eMob;
    public Char eChar;
    public Game106 effCharPaint;
    public boolean Class5;
    
    public final int Class1() {
        return this.effCharPaint.Class2[this.Class1].Class3;
    }
}
