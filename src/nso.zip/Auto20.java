// 
// Decompiled by Procyon v0.5.36
// 

public class Auto20 extends Auto10
{
}
