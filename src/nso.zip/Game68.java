// 
// Decompiled by Procyon v0.5.36
// 

public final class Game68
{
    public boolean Class1;
    public int Class2;
    public boolean Class3;
    
    public Game68() {
        this.Class2 = -1;
        this.Class3 = false;
    }
}
