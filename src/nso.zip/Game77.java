// 
// Decompiled by Procyon v0.5.36
// 

public final class Game77
{
    public String Class1;
    mFont Class2;
    public int Class3;
    
    public Game77(final String class1) {
        this.Class2 = mFont.number_red;
        this.Class1 = class1;
        this.Class3 = 20;
    }
    
    public Game77(final String class1, final mFont class2, final int class3) {
        this.Class2 = class2;
        this.Class1 = class1;
        this.Class3 = class3;
    }
}
