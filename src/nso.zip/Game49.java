// 
// Decompiled by Procyon v0.5.36
// 

public final class Game49
{
    public short Class1;
    public byte Class2;
    public byte Class3;
}
