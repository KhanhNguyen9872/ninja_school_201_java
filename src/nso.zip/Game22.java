// 
// Decompiled by Procyon v0.5.36
// 

public final class Game22
{
    private int Class1;
    private int Class2;
    private int Class3;
    private String Class4;
    private String Class5;
    private int Class6;
    private int Class7;
    
    private Game22() {
    }
}
