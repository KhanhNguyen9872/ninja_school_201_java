// 
// Decompiled by Procyon v0.5.36
// 

public final class Game51
{
    public int[] Class1;
    
    static {
        final byte[] array = { 0, 1, 2, 1, 0, 1, 2, 1, 0, 1, 2, 1, 0, 1, 2, 1, 0, 1, 2, 1, 0, 1, 2, 1, 0 };
        final int[] array2 = { 0, 15, 37, 52, 75, 105, 127, 142, 165, 195, 217, 232, 255, 285, 307, 322, 345, 370 };
        final int[] array3 = { 0, 0, 0, 7, 6, 6, 6, 2, 2, 3, 3, 4, 5, 5, 5, 1 };
    }
    
    public Game51() {
        this.Class1 = new int[3];
    }
}
