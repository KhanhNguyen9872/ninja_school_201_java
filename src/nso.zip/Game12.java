// 
// Decompiled by Procyon v0.5.36
// 

public final class Game12
{
    private int Class1;
    private int Class2;
    private int Class3;
    private int Class4;
    private int Class5;
    private int Class6;
    private int Class7;
    private int Class8;
    private int Class9;
    private static int[] Class10;
    
    static {
        final int[] array = { 10, 5, 11 };
        final int[] array2 = { 10, 5, 11 };
    }
    
    private static void Class1() {
        throw null;
    }
}
