// 
// Decompiled by Procyon v0.5.36
// 

public final class Game18
{
    public int Class1;
    public int Class2;
    public int Class3;
    public int Class4;
    public int Class5;
    public int Class6;
    public int Class7;
    public int Class8;
    public int Class9;
    public int Class10;
    public int Class11;
    public int Class12;
    public int Class13;
}
