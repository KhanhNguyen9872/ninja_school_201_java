// 
// Decompiled by Procyon v0.5.36
// 

public final class Game106
{
    public int Class1;
    public Game90[] Class2;
}
