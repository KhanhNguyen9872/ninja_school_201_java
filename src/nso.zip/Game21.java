// 
// Decompiled by Procyon v0.5.36
// 

public abstract class Game21
{
    public static MyVector Class1;
    public static MyVector Class2;
    public static MyVector Class3;
    public static MyVector Class4;
    
    static {
        Game21.Class1 = new MyVector();
        Game21.Class2 = new MyVector();
        Game21.Class3 = new MyVector();
        Game21.Class4 = new MyVector();
    }
    
    public abstract void switchToMe();
    
    public abstract void Class1(final mGraphics p0);
}
