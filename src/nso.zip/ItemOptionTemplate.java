// 
// Decompiled by Procyon v0.5.36
// 

public final class ItemOptionTemplate
{
    public int id;
    public String name;
    public int type;
}
