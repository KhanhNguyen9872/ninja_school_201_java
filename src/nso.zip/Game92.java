// 
// Decompiled by Procyon v0.5.36
// 

public final class Game92
{
    public short Class1;
    public short Class2;
    public String Class3;
    public boolean Class4;
    
    public Game92(final String class3, final short class4, final short class5) {
        this.Class4 = false;
        this.Class1 = class4;
        this.Class2 = class5;
        this.Class3 = class3;
    }
}
